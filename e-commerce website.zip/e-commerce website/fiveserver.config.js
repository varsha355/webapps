module.exports = {
    php: "C:\\xampp\\php\\php.exe"            // Update this with the correct path
}
<!DOCTYPE html>
<html lang="en">
<head>
        <style type="text/css">
            h5{
                color: brown;
            }
            .p1{
                text-align: center;
            }
        </style>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>About us | Ecomm Store</title>
        <link href="bootstrap.min.css" rel="stylesheet">
        <link href="style.css" rel="stylesheet">
        <script src="query.js"></script>
        <script src="bootstrap.min.js"></script>
    </head>
<body>
<?php
include 'header.php';
?>
<div class="container" id="content">
    <img src="team1.jpg" style="float: center;">
    <div class="row">
        <div class="col" align="center">
            <h1><mark>WHO WE ARE</mark></h1><br>
            <p id="p1">Ecomm store is popular in the e-commerce industry, with a commitment to success and a record of achievement that continues a tradition of delivering excellence.<br><br>
            </p>
        </div>
        <div class="col" align="center">
            <h1><mark>FOCUS</mark></h1><br>
            <p id="p1">We try to have a positive impact on customers, employees, small businesses, the economy, and communities.<br><br>                 <ul>
                    <li>Development:<br>Our Focus is completely on growth in new trends.</li><br>
                    <li>Market Penetration:<br>We aim to gain more profits from markets.</li><br>
                                   </ul>
            </p>
        </div>
</div>
</body>
</html>